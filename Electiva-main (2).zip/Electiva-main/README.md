# Electiva

# Proyecto Electiva de Profundización I - Creación de APIs

## Integrantes:
 Roy Rojas [@Royrojas11](https://github.com/Royrojas11).
 Jeremy Carrasquilla [@Jeremycactus](https://github.com/Jeremycactus).
John Chacon [@joh0312](https://github.com/joh0312).
 
 # Sprint 1:
 
 ## Historia de Usuario EP-001 
 
 ![1](https://user-images.githubusercontent.com/5382![](../../Downloads/WhatsApp%20Image%202022-09-08%20at%2020.28.06%20(1).jpeg)2139/189217756-837ef565-0d53-426c-a8de-15c4ed60a2e4.jpeg)

 ![2](https://user-images.githubusercontent.com/5382213![](../../Downloads/WhatsApp%20Image%202022-09-08%20at%2020.28.06%20(1).jpeg)9/189217806-6241da24-acb8-4263-9a28-5241428112e8.jpeg)

 
  
  ## Historia Técnica EP-002 

 ![3](https://user-images.githubusercontent.com/5![](../../Downloads/WhatsApp%20Image%202022-09-08%20at%2020.35.44.jpeg)3822139/189219692-602d209e-61e1-432e-945d-94f0c38f2f2b.jpeg)
